Full-Text RSS Site Patterns
---------------------------

Site patterns allow you to specify what should be extracted from specific sites.

Please see http://help.fivefilters.org/customer/portal/articles/223153-site-patterns for more information.